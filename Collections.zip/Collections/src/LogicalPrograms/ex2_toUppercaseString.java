package LogicalPrograms;

import java.util.Scanner;

public class ex2_toUppercaseString {
	
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		
		System.out.print("Enter Your name in lowercase:  ");
		String s=scan.next();
		
		System.out.println(s.toUpperCase());
		
		System.out.print("Enter your Surname: ");
		String n=scan.next();
		System.out.println(n.toUpperCase());
		
		
		
		
		
		
		
	}

}
