package LogicalPrograms;

public class EX9_calculate_white_spaces_in_String {

	public static void main(String[] args) {
		
		String str="A B  C D";
		int count=0;
		
		for(int i=0;i<str.length();i++) {
			
			char ch = str.charAt(i);
			if(ch==' ')
			{
				count++;
			}
		}
		System.out.println(count);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
