package LogicalPrograms;

public class EX4_reverse_String {
	
	public static void main(String[] args) {
		
		String org="ABBA";
		String rev="";
		
		for(int i=org.length()-1;i>=0;i--)
		{
			rev=rev+org.charAt(i);
			
		}
		
		System.out.println("The original string is "+org);
		System.out.println("The reverse String is "+rev);
		
		if(org.equals(rev))
		{
			System.out.println("The given String is polidrome");
		}
		
		else {
			System.out.println("The given String is not polidrome");
		}
		
		
		
		
		
		
		
		
		
	}

}
