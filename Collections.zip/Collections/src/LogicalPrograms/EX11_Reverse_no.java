package LogicalPrograms;

import java.util.Scanner;

public class EX11_Reverse_no {
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter No; ");
		int orgno=scan.nextInt();
		String org=Integer.toString(orgno);    //convert int to string 
		
		String rev="";
		for(int i=org.length()-1;i>=0;i--) {
			rev=rev+org.charAt(i);
		}
		
		int revNum=Integer.parseInt(rev);
		System.out.println("Reversed int is "+ revNum);
		
		
		
		
		
		
		
		
		
		
	}

}
