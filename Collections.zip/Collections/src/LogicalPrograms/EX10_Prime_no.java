package LogicalPrograms;

import java.util.Scanner;

public class EX10_Prime_no {
	
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.print ("Enter any no: ");
		int num1=scan.nextInt();
		
		int count=0;
		
		for(int i=2;i<num1;i++)
		{
			if(num1%i==0)
			{
				count++;
				break;
			}
		}
		
		if(count==1)
		{
			System.out.println("The given no is not prime");
		}
		else
		{
			System.out.println("The given no is prime");
		}
		
		
	}

}
