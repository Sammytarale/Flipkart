package LogicalPrograms;

public class EX3_multiply_2_no_without_multipyOP {
	
	
	public static void main(String[] args) {
		
		
		
		int num1=10;
		int num2=20;
		int sum=0;
		for(int i=1;i<=num2;i++) {
			
			sum=sum+num1;	
		}
		System.out.println("Multiplication is: "+sum);
		
		
		
		
		
		
		
		
		
		
		
	}
	
	

}
