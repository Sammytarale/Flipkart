package LogicalPrograms;

import java.util.Scanner;

public class EX5_polidrome {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter a String: ");
		String org =scan.next();
		String rev = "";

		for (int i = org.length() - 1; i >= 0; i--) {
			rev=rev+org.charAt(i);
		}
		System.out.println("The reverse String is :"+rev);
		
		if(org.equals(rev)){
			System.out.println("The given String is Polidrome");
		}
		else {
			System.out.println("The given String is not polidrome");
		}
	}
	
	
	

}
