package LogicalPrograms;

public class EX12_REverseNOWithoutStringfunction {
	
	public static void main(String[] args) {
		int orgNo=123456;
		int rev=0;
		
		for(int i=orgNo;i>0;i=i/10) {
			int no=i%10;
			rev=rev*10+no;
		}
		System.out.println(rev);
		
		int num=123456789;
		int rv=0;
		while(num>0) {
			int rem=num%10;
			rv=rv*10+rem;
			num=num/10;
		}
		System.out.println(rv);
		
		
		
		
	}

}
