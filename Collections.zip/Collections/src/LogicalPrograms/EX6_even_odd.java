package LogicalPrograms;

import java.util.Scanner;

public class EX6_even_odd {
	
	public static void main(String[] args) {
		
		
		
		Scanner scan =new Scanner(System.in);
		System.out.print("Enter any no to find even or odd :  ");
		
		int num=scan.nextInt();
		
		if(num%2==0) {
			System.out.println("The given no is even");
		}
		else {
			System.out.println("The given no is odd");
		}
		
	}

}
