package LogicalPrograms;

import java.util.Scanner;

public class ex1_AcceptInputFromUser {


	public static void main(String[] args) {
		
		Scanner scan =new Scanner(System.in);
		System.out.print("Enter Num1: ");
		int num1=scan.nextInt();
	
		System.out.print("Enter num2: ");
		int num2=scan.nextInt();
		
		System.out.println(num1+num2);
		
		System.out.println(num1-num2);
		System.out.println(num1*num2);
		System.out.println(num1/num2);	
		
		s();
		
	}
	
	public static void s() {
		
		Scanner scan=new Scanner(System.in);
		
		System.out.print("Enter num1 :");
		
		int num1=scan.nextInt();
		
		System.out.println("Enter num2 :");
		int num2=scan.nextInt();
		
		System.out.println(num1+num2);
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
}
