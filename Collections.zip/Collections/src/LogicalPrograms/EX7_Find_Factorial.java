package LogicalPrograms;

public class EX7_Find_Factorial {
	
	public static void main(String[] args) {
		
		int a=4;
		int fact=1;
		
		for(int i=a;i>=1;i--) {
			
			fact=fact*i;
					
		}
		
		System.out.println("the factorial is : "+fact);
		
			
		
	}

}
