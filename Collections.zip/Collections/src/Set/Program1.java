package Set;

import java.util.ArrayList;

public class Program1 {
	
	public static void main(String[] args) {

		ArrayList<String> al=new ArrayList<String>();
		al.add("abc");
		al.add("xyz");
//		al.add(10);
//		al.add('A');
		
		
		for(String s1: al) 
		{
			System.out.println(s1);
		}
		
		
	}

}
