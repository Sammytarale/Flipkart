package Set;

import java.util.TreeSet;

public class program {

	public static void main(String[] args) {
		
		
TreeSet<Integer> tr=new TreeSet<Integer>();    //generic
		
		tr.add(10);
		tr.add(200);
		
		
		
		for(Integer s1: tr)
		{
			System.out.println(s1);
		}
		
		
		
	}
}
