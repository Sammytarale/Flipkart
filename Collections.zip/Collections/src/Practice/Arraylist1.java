package Practice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

import Arraylist.Arraylist;

public class Arraylist1 {
	
	
	public static void main(String[] args) {
		

		ArrayList al=new ArrayList(20);
	
		al.add("Shyam");
		al.add("Naayn");
		al.add("Sachin");
		al.add("484");
		al.add(null);
		al.add("2541");
		al.add(110);
		al.add(110.14f);
		
		System.out.println(al);
		System.out.println(al.size());
		System.out.println(al.isEmpty());
		System.out.println(al.contains("Sachin"));
		System.out.println(al.get(3));
		
				
		
		
		al.add(3, 145);
		System.out.println(al);

		al.remove(3);
		
		System.out.println(al);
		System.out.println("______________________________________________");
		// __________print arraylist using iterater cursor
		
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
		System.out.println(itr.next());
		
		}
		

		System.out.println("_____________________________________");
		// __________print arraylist using listiterater cursor
		
		ListIterator it = al.listIterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();
		
		
		System.out.println("By using for loop");
		for (int i = 0; i <=al.size()-1; i++) {
			System.out.println(al.get(i));
			
		}
		
		System.out.println();
		System.out.println("By using for each loop");
			
		for( Object a:al) {
			System.out.println(a);
		}
		
	}

}
