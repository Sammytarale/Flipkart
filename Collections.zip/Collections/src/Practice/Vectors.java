package Practice;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class Vectors {
	
	public static void main(String[] args) {
		
		Vector vs=new Vector();
		
		vs.add("Shaym");
		System.out.println(vs);
		
		vs.add(1520);
		vs.add(1520);

		vs.add(1520);

		vs.add(1520);
		vs.add(1520);

		
		System.out.println(vs);
		
		System.out.println(vs.size());
		
		System.out.println(vs.isEmpty());
		
		System.out.println(vs.get(1));
		System.out.println(vs.contains(1520));
		
		
		vs.add(65200);
		vs.removeElementAt(0);
		System.out.println(vs);
		
		System.out.println();
		System.out.println();

		Iterator itr = vs.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println();
		System.out.println();

		ListIterator li = vs.listIterator();
		while (li.hasNext()) {
			System.out.println(li.next());
		}
		
		
		
		
		
	}

}
