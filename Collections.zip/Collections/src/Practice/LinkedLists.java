package Practice;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedLists {
	
	public static void main(String[] args) {
		
		LinkedList ll=new LinkedList();
		
		
		ll.add(1524);
		ll.add(654);
		ll.add(1524);
		ll.add(654);
		ll.add(1524);
		ll.add(654);
		
		
		
		
		
		Iterator itr = ll.iterator();
		while (itr.hasNext()) {
		System.out.println(itr.next());
		
		}
		

		System.out.println("_____________________________________");
		// __________print arraylist using listiterater cursor
		
		ListIterator it = ll.listIterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();
		
		
		System.out.println("By using for loop");
		for (int i = 0; i <=ll.size()-1; i++) {
			System.out.println(ll.get(i));
			
		}
		
		System.out.println();
		System.out.println("By using for each loop");
			
		for( Object a:ll) {
			System.out.println(a);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	

}
